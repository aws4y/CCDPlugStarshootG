package com.droid.usbcam;

class CamConst {
	private static final int CONST = 0x0547;
	private static final int MSG_CONST = CONST + 0x21;
	private static final int RET_CONST = CONST + 0x41;
	public static final int MSG_UPDATE = MSG_CONST + 26;
	public static final int MSG_CAP_SUCCESS = RET_CONST + 9;
	public static final int MSG_CAP_FAILED = RET_CONST + 10;
	public static final int REQ_PERMISSIONS = 100;
}
