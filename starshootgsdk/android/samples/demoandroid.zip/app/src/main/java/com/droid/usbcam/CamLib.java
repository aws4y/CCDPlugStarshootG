package com.droid.usbcam;

import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.RectF;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.Message;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;

public class CamLib {
	private static CamLib sInstance;
	private static Handler localHandler = null;
	private static final int FLOAT_BYTE_LENGTH = 4;
	private FloatBuffer mVertexBuffer;
	private int mProgram = 0;
	private int mPositionAttributeLocation;
	private int mTexCoordAttributeLocation;
	private int mCurrentTextureId;

	private float[] mVertices = {-1.f, -1.f, 0.f, 0.f, 1.f, 1.f, -1.f, 0.f, 1.f, 1.f, -1.f, 1.f, 0.f, 0.f, 0.f, 1.f, 1.f, 0.f, 1.f, 0.f};

	void setup() {
		mProgram = createProgram();
		mPositionAttributeLocation = GLES20.glGetAttribLocation(mProgram, "position");
		mTexCoordAttributeLocation = GLES20.glGetAttribLocation(mProgram, "TexCoordIn");
		GLES20.glDisable(GL10.GL_CULL_FACE);
		mVertexBuffer = ByteBuffer.allocateDirect(mVertices.length * FLOAT_BYTE_LENGTH).order(ByteOrder.nativeOrder()).asFloatBuffer();
		mVertexBuffer.put(mVertices);
		mVertexBuffer.position(0);
		GenTexture();
	}

	private void GenTexture() {
		int[] textures = new int[2];
		GLES20.glGenTextures(2, textures, 0);
		GLES20.glBindTexture(GLES10.GL_TEXTURE_2D, textures[0]);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GLES10.GL_TEXTURE_MIN_FILTER, GLES10.GL_NEAREST);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GLES10.GL_TEXTURE_MAG_FILTER, GLES10.GL_LINEAR);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GLES10.GL_TEXTURE_WRAP_S, GLES10.GL_CLAMP_TO_EDGE);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GLES10.GL_TEXTURE_WRAP_T, GLES10.GL_CLAMP_TO_EDGE);
		mCurrentTextureId = textures[0];
	}

	void render(Matrix transformMatrix, RectF rect, GL10 gl) {
		if (mCurrentTextureId == 0)
			return;
		GLES20.glClearColor(0.1490196f, 0.1490196f, 0.1490196f, 0.f);
		GLES20.glClear(GL10.GL_COLOR_BUFFER_BIT);
		GLES20.glUseProgram(mProgram);
		GLES20.glActiveTexture(GLES10.GL_TEXTURE_2D);
		GLES20.glBindTexture(GLES10.GL_TEXTURE_2D, mCurrentTextureId);
		update();
		GLES20.glUniform1i(GLES20.glGetUniformLocation(mProgram, "bDrawWindow"), 0);
		float[] points = {rect.left, rect.top, rect.right, rect.top, rect.left, rect.bottom, rect.right, rect.bottom};
		transformMatrix.mapPoints(points);
		mVertices[0] = points[0];
		mVertices[1] = points[1];
		mVertices[5] = points[2];
		mVertices[6] = points[3];
		mVertices[10] = points[4];
		mVertices[11] = points[5];
		mVertices[15] = points[6];
		mVertices[16] = points[7];
		mVertexBuffer.position(0);
		mVertexBuffer.put(mVertices);
		mVertexBuffer.position(0);
		GLES20.glVertexAttribPointer(mPositionAttributeLocation, 3, GLES10.GL_FLOAT, false, 5 * FLOAT_BYTE_LENGTH, mVertexBuffer);
		mVertexBuffer.position(3);
		GLES20.glVertexAttribPointer(mTexCoordAttributeLocation, 2, GLES10.GL_FLOAT, false, 5 * FLOAT_BYTE_LENGTH, mVertexBuffer);
		GLES20.glEnableVertexAttribArray(mPositionAttributeLocation);
		GLES20.glEnableVertexAttribArray(mTexCoordAttributeLocation);
		GLES20.glDrawArrays(GLES10.GL_TRIANGLE_STRIP, 0, 4);
	}

	private int createProgram() {
		final String mVertexShader = "attribute vec4 position; attribute vec2 TexCoordIn; varying vec2 TexCoordOut;" +
				"void main() { gl_Position = position; TexCoordOut = TexCoordIn;}";

		final String mFragmentShader = "uniform bool bDrawWindow; precision mediump float; varying vec2 TexCoordOut;" +
				" uniform vec4 vColor; uniform sampler2D texture1; void main() { " +
				" if (bDrawWindow) gl_FragColor = vec4(1,1,1,0); else gl_FragColor = texture2D(texture1, TexCoordOut); }";
		final int program = GLES20.glCreateProgram();
		final int vShader = getShader(GLES20.GL_VERTEX_SHADER, mVertexShader);
		final int fShader = getShader(GLES20.GL_FRAGMENT_SHADER, mFragmentShader);
		GLES20.glAttachShader(program, vShader);
		GLES20.glAttachShader(program, fShader);
		GLES20.glLinkProgram(program);
		GLES20.glUseProgram(program);
		return program;
	}

	private int getShader(int type, String shaderSource) {
		final int shader = GLES20.glCreateShader(type);
		GLES20.glShaderSource(shader, shaderSource);
		GLES20.glCompileShader(shader);
		int[] compiled = new int[1];
		GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
		return shader;
	}

	String GetCamName(int index) {
		return getCamNamebyIndex(index);
	}

	String GetCamID(int index) {
		return getCamIDbyIndex(index);
	}

	void Init() {
		init();
	}

	int EnumCams() {
		return enumCams();
	}

	int OpenCamera(int index) {
		return openCamera(index);
	}

	void RestartCamera() {
		GenTexture();
	}

	void ReleaseCamera() {
		releaseCamera();
	}

	boolean IsAlive() {
		return isAlive();
	}

	Point GetPreviewSize() {
		int[] array = getPreviewSize();
		return new Point(array[0], array[1]);
	}

	void setLocalHandler(Handler handler) {
		localHandler = handler;
	}

	void ClearData() {
		clearData();
	}

	static CamLib getInstance() {
		synchronized (CamLib.class) {
			if (sInstance == null)
				sInstance = new CamLib();
		}
		return sInstance;
	}

	static {
		System.loadLibrary("starshootg");
		System.loadLibrary("jnicam");

	}

	public void DoUpdateFrame(int width, int height) {
		if (localHandler != null) {
			Message Msg = localHandler.obtainMessage();
			Msg.what = CamConst.MSG_UPDATE;
			Msg.arg1 = width;
			Msg.arg2 = height;
			localHandler.sendMessage(Msg);
		}
	}

	public void CaptureCallBack(int status) {
		if (localHandler != null) {
			Message Msg = localHandler.obtainMessage();
			Msg.what = status == 0 ? CamConst.MSG_CAP_SUCCESS : CamConst.MSG_CAP_FAILED;
			localHandler.sendMessage(Msg);
		}
	}

	private native int[] getPreviewSize();

	private native void init();

	private native int enumCams();

	private native void update();

	private native int openCamera(int index);

	private native void releaseCamera();

	private native boolean isAlive();

	private native String getCamNamebyIndex(int i);

	private native String getCamIDbyIndex(int i);

	private native void clearData();
}
