package com.droid.usbcam;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class CamListActivity extends Activity {
	public static CamLib mLib = null;
	private CamListAdapter mAdapter;
	private volatile ArrayList<CamListItem> mData = new ArrayList<>();

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.lyt_cameralist);
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
		getWindow().setStatusBarColor(getResources().getColor(R.color.theme_background));
		findViews();
		if (null == mLib)
			mLib = CamLib.getInstance();
		mLib.Init();
	}

	@Override
	protected void onStart() {
		super.onStart();
		EnumCameras();
	}

	private void findViews() {
		GridView camList = findViewById(R.id.gv_camlist);
		mAdapter = new CamListAdapter(CamListActivity.this, mData);
		camList.setAdapter(mAdapter);
		camList.setOnItemClickListener(onCamListClicked);
	}

	AdapterView.OnItemClickListener onCamListClicked = new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			int index = 0;
			if (mData != null) {
				CamListItem item = mData.get(position);
				if (item == null)
					return;
				index = item.getIndex();
			}
			Intent intent = new Intent(CamListActivity.this, MainActivity.class);
			intent.putExtra("INDEX", index);
			startActivity(intent);
		}
	};

	private synchronized void EnumCameras() {
		final int camNum = mLib.EnumCams();
		mData.clear();
		for (int i = 0; i < camNum; i++) {
			String id = mLib.GetCamID(i);
			String name = mLib.GetCamName(i);
			mData.add(new CamListItem(name, id, i));
		}
		mAdapter.notifyDataSetChanged();
	}

	public static class CamListItem {
		private String mName;
		private String mID;
		private int mIndex;

		CamListItem(String name, String id, int index) {
			mName = name;
			mID = id;
			mIndex = index;
		}

		public void setName(String name) {
			mName = name;
		}

		public void setID(String id) {
			mID = id;
		}

		public void setIndex(int index) {
			mIndex = index;
		}

		int getIndex() {
			return mIndex;
		}

		String getName() {
			return mName;
		}

		public String getID() {
			return mID;
		}
	}

	public static class CamListAdapter extends BaseAdapter {
		private LayoutInflater mInflater;
		private ArrayList<CamListItem> mData;

		private static class ViewHolder {
			TextView text;
		}

		CamListAdapter(Context context, ArrayList<CamListItem> data) {
			mInflater = LayoutInflater.from(context);
			mData = data;
		}

		@Override
		public int getCount() {
			return mData.size();
		}

		@Override
		public Object getItem(int position) {
			return mData.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View v, ViewGroup parent) {
			ViewHolder holder;
			if (v == null) {
				v = mInflater.inflate(R.layout.camera_items, null);
				holder = new ViewHolder();
				holder.text = v.findViewById(R.id.txt_camname);
				v.setTag(holder);
			} else {
				holder = (ViewHolder) v.getTag();
			}
			holder.text.setText(mData.get(position).getName());
			return v;
		}
	}
}
