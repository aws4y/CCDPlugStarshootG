package com.droid.usbcam;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class CamRender implements GLSurfaceView.Renderer {
	private int mCurrentBitmapWidth = 0;
	private int mCurrentBitmapHeight = 0;
	private int mCurrentWidth = 0;
	private int mCurrentHeight = 0;
	private boolean mbInit = false;
	private Matrix mTransformMatrix;
	private RectF mImageBoundsRect;
	private CamLib mLib = null;

	CamRender(CamLib lib) {
		mLib = lib;
		mTransformMatrix = new Matrix();
		mImageBoundsRect = new RectF(-1, -1, 1, 1);
	}

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		mLib.setup();
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		mCurrentWidth = width;
		mCurrentHeight = height;
		GLES20.glViewport(0, 0, width, height);
		setupRenderRegion();
	}

	@Override
	public void onDrawFrame(GL10 gl) {
		mLib.render(mTransformMatrix, mImageBoundsRect, gl);
	}

	void setRenderSize(int width, int height) {
		mCurrentBitmapWidth = width;
		mCurrentBitmapHeight = height;
	}

	void setupRenderRegion() {
		if (mCurrentBitmapHeight == 0 || mCurrentBitmapWidth == 0 || mCurrentHeight == 0 || mCurrentWidth == 0) {
			return;
		}
		float halfW = 1.f, halfH = 1.f;
		float imageAspect = 1.0f * mCurrentBitmapWidth / mCurrentBitmapHeight;
		float renderAspect = 1.0f * mCurrentWidth / mCurrentHeight;
		if (imageAspect > renderAspect) {
			halfW = Math.min(1.f, 1.0f * mCurrentBitmapWidth / mCurrentWidth);
			halfH = halfW * renderAspect / imageAspect;
		} else {
			halfH = Math.min(1.f, 1.0f * mCurrentBitmapHeight / mCurrentHeight);
			halfW = imageAspect / renderAspect;
		}
		mImageBoundsRect.set(-halfW, -halfH, halfW, halfH);
	}

	boolean openCamera(int index) {
		if (!mbInit) {
			mbInit = (0 == mLib.OpenCamera(index));
		}
		return mbInit;
	}
}
