package com.droid.usbcam;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.WindowManager;
import java.lang.ref.WeakReference;

public class MainActivity extends Activity {
	private static CamLib mLib = null;
	private Handler mHandler = new CamHandler(this);
	private CamView mGlView = null;
	private int mVideoW = 0;
	private int mVideoH = 0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_main);
		if (null == mLib)
			mLib = CamLib.getInstance();
		mLib.setLocalHandler(mHandler);
		mGlView = findViewById(R.id.gl_view);
		int index = getIntent().getIntExtra("INDEX", 0);
		if (mGlView.openCam(index)) {
			Point size = mLib.GetPreviewSize();
			initSize(size.x, size.y);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (mLib != null && mLib.IsAlive()) {
			mGlView.onResume();
			mLib.RestartCamera();
			update();
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mLib != null && mLib.IsAlive()) {
			mGlView.onPause();
			mLib.ClearData();
		}
	}

	@Override
	protected void onDestroy() {
		mLib.ReleaseCamera();
		mHandler = null;
		super.onDestroy();
	}

	public void update() {
		mGlView.requestRender();
	}

	public void update(int width, int height) {
		if (width != mVideoW || height != mVideoH) {
			initSize(width, height);
			mVideoW = width;
			mVideoH = height;
		}
		update();
	}

	public void initSize(int videoWidth, int videoHeight) {
		if (mGlView != null)
			mGlView.setVideoSize(videoWidth, videoHeight);
	}

	public static class CamHandler extends Handler {
		private WeakReference<MainActivity> mOwner;

		CamHandler(MainActivity owner) {
			mOwner = new WeakReference<>(owner);
		}

		@Override
		public void handleMessage(Message msg) {
			MainActivity mainActivity = mOwner.get();
			if (msg.what == CamConst.MSG_UPDATE) {
				mainActivity.update(msg.arg1, msg.arg2);
			}
		}
	}
}