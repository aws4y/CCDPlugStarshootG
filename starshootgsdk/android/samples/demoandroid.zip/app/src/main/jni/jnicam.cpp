#include <jni.h>
#include <android/log.h>
#include <pthread.h>
#include <GLES/gl.h>
#include <GLES2/gl2.h>
#include <iostream>
#include "starshootg.h"

#define  LOG_TAG    "JNI_CAM"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

jobject gObject = nullptr;
JavaVM *gLocalVm;
unsigned char *gData = nullptr;
int giVideoW = 0, giVideoH = 0;
bool gbFoundCam = false, gbInited = false;
StarshootgDeviceV2 gAllTi[STARSHOOTG_MAX];
StarshootgDeviceV2 gTi = {0};
HStarshootg gHcam = nullptr;
pthread_mutex_t gMutex;

static void onEventImage() {
    bool isAttached = false;
    JNIEnv *env = nullptr;
    if (gLocalVm->GetEnv((void **) &env, JNI_VERSION_1_2) < 0) {
        if (gLocalVm->AttachCurrentThread(&env, nullptr) < 0)
            return;
        isAttached = true;
    }
    jclass lds = env->GetObjectClass(gObject);
    unsigned width = 0, height = 0;
    if (JNI_OK == Starshootg_PullImage(gHcam, nullptr, 24, &width, &height)) {
        giVideoW = width;
        giVideoH = height;
        if (nullptr == gData)
            gData = (unsigned char*)malloc(TDIBWIDTHBYTES(24 * giVideoW) * giVideoH);
        pthread_mutex_lock(&gMutex);
        if (JNI_OK == Starshootg_PullImage(gHcam, gData, 24, nullptr, nullptr)) {
            jmethodID doUpdateFrame = env->GetMethodID(lds, "DoUpdateFrame", "(II)V");
            if (doUpdateFrame != nullptr)
                env->CallVoidMethod(gObject, doUpdateFrame, giVideoW, giVideoH);
        }
        pthread_mutex_unlock(&gMutex);
    }
    if (isAttached)
        gLocalVm->DetachCurrentThread();
}

static void camCallback(unsigned nEvent, void *pCallbackCtx) {
    if (STARSHOOTG_EVENT_IMAGE == nEvent) {
        onEventImage();
    }
}

extern "C" {
JNIEXPORT void JNICALL Java_com_droid_usbcam_CamLib_init(JNIEnv *env, jobject obj);
JNIEXPORT jint JNICALL Java_com_droid_usbcam_CamLib_enumCams(JNIEnv *env, jobject instance);
JNIEXPORT int JNICALL Java_com_droid_usbcam_CamLib_openCamera(JNIEnv *env, jobject obj, jint index);
JNIEXPORT void JNICALL Java_com_droid_usbcam_CamLib_update(JNIEnv *env, jobject obj);
JNIEXPORT jintArray JNICALL Java_com_droid_usbcam_CamLib_getPreviewSize(JNIEnv *env, jobject obj);
JNIEXPORT void JNICALL Java_com_droid_usbcam_CamLib_clearData(JNIEnv *env, jobject instance);
JNIEXPORT jboolean JNICALL Java_com_droid_usbcam_CamLib_isAlive(JNIEnv *env, jobject obj);

JNIEXPORT void JNICALL
Java_com_droid_usbcam_CamLib_init(JNIEnv *env, jobject obj) {
    gObject = env->NewGlobalRef(obj);
    pthread_mutex_init(&gMutex, nullptr);
}

JNIEXPORT jint JNICALL
Java_com_droid_usbcam_CamLib_openCamera(JNIEnv *env, jobject obj, jint index) {
    if (!gbFoundCam)
        return JNI_ERR;
    if (gHcam) {
        Starshootg_Close(gHcam);
        gHcam = nullptr;
    }
    if (0 != gAllTi[index].id[0])
        gTi = gAllTi[index];
    gHcam = Starshootg_Open(gTi.id);
    if (gHcam) {
        LOGE("Open Camera Success!");
        int ret = Starshootg_StartPullModeWithCallback(gHcam, camCallback, nullptr);
        if (JNI_OK != ret) {
            Starshootg_Close(gHcam);
            gHcam = nullptr;
            LOGE("Starshootg_StartPullModeWithCallback failed with ret = %d\n", ret);
            return JNI_ERR;
        }
        Starshootg_put_MaxAutoExpoTimeAGain(gHcam, 50000, 2100);
        Starshootg_put_AutoExpoEnable(gHcam, 1);//open auto exposure

        gbInited = true;
        return JNI_OK;
    }
    return JNI_ERR;
}

JNIEXPORT void JNICALL Java_com_droid_usbcam_CamLib_update(JNIEnv *env, jobject obj) {
    pthread_mutex_lock(&gMutex);
    if (gData != nullptr)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, giVideoW, giVideoH, 0, GL_RGB, GL_UNSIGNED_BYTE, gData);
    pthread_mutex_unlock(&gMutex);
}

JNIEXPORT jintArray JNICALL
Java_com_droid_usbcam_CamLib_getPreviewSize(JNIEnv *env, jobject obj) {
    int width = 0, height = 0;
    if (gHcam)
        Starshootg_get_Size(gHcam, &width, &height);
    int size[2];
    size[0] = width;
    size[1] = height;
    jintArray array = env->NewIntArray(2);
    env->SetIntArrayRegion(array, 0, 2, size);
    return array;
}

JNIEXPORT jboolean JNICALL Java_com_droid_usbcam_CamLib_isAlive(JNIEnv *env, jobject obj) {
    return gbInited;
}
JNIEXPORT void JNICALL Java_com_droid_usbcam_CamLib_releaseCamera(JNIEnv *env, jobject obj) {
    Starshootg_Close(gHcam);
    gHcam = nullptr;
    gbInited = false;
    gTi = {0};
}

JNIEXPORT jstring JNICALL
Java_com_droid_usbcam_CamLib_getCamNamebyIndex(JNIEnv *env, jobject obj, jint index) {
    return env->NewStringUTF(gAllTi[index].displayname);
}

JNIEXPORT jstring JNICALL
Java_com_droid_usbcam_CamLib_getCamIDbyIndex(JNIEnv *env, jobject obj, jint index) {
    return env->NewStringUTF(gAllTi[index].id);
}

JNIEXPORT int JNICALL
Java_com_droid_usbcam_CamLib_enumCams(JNIEnv *env, jobject instance) {
    memset(gAllTi, 0, STARSHOOTG_MAX * sizeof(StarshootgDevice));
    const int num = Starshootg_EnumV2(gAllTi);
    LOGE("Found %d cameras!", num);
    gbFoundCam = (num > 0);
    return num;
}

JNIEXPORT void JNICALL
Java_com_droid_usbcam_CamLib_clearData(JNIEnv *env, jobject instance) {
    pthread_mutex_lock(&gMutex);
    memset(gData, 0, TDIBWIDTHBYTES(24 * giVideoW) * giVideoH);
    pthread_mutex_unlock(&gMutex);
}

jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    gLocalVm = vm;
    return JNI_VERSION_1_2;
}

void JNI_OnUnload(JavaVM *vm, void *reserved) {
    bool isAttached = false;
    JNIEnv *env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_2) < 0) {
        if (vm->AttachCurrentThread(&env, nullptr) < 0)
            return;
        isAttached = true;
    }
    env->DeleteGlobalRef(gObject);
    if (isAttached)
        vm->DetachCurrentThread();
    if (gData) {
        free(gData);
        gData = nullptr;
    }
}
}

