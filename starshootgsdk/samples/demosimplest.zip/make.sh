#!/bin/bash
gcc -Wl,-rpath -Wl,'$ORIGIN' -L. -g -o demosimplest demosimplest.cpp -lstarshootg
